/* Include express, a framework for creating servers */
var express = require('express');

/* Include the MinoCloud node module that will allow 
 * us to create MinoCloud objects that we can use to 
 * interact with the MinoCloud API. */
var MinoCloud = require('minocloud');

/* Include the app settings. This is an object that 
 * contains the app's username, API key and a list 
 * of types that it will use. */
var app_settings = require("./app_settings");

/* Include the activation method that the app will use 
 * when a new user signs up to the server. */
var activate = require('./activate');

/* Include the app's API so that we can call it. */
var api = require('./api');

/* Create a new express server. */
var server = express();

/* Tell express to process the body so that POST 
 * variables are available. */
server.use(express.bodyParser());

/* Tell express to process cookies so that 
 * MinoCloud can use them. */
server.use(express.cookieParser());

/* Direct requests that don't comply to the paths 
 * specified below to static content if it exists. */
server.use(express.static(__dirname + '/public'));

/* Requests for the domain. */
server.get('/', function (req, res) {

  /* Create a MinoCloud object just for the request. */
  var minocloud = new MinoCloud(app_settings.username,app_settings.api_key);

  /* Attempt MinoCloud authentication. Ignore the 
   * result, it can be retrieved later. */
  minocloud.authenticate(req, res, function(authenticated){

    /* You can replace this with your template 
     * engine of choice. The minocloud.toolbar() 
     * function returns a block of html that 
     * includes a link to a javascript file on 
     * minocloud.com that initializes the 
     * toolbar. It also includes the app's 
     * username and the username of the user 
     * that is signed in (null if not signed in) 
     * as MinoCloud_app and MinoCloud_user 
     * respectively. */
    res.writeHead(200, {"Content-Type": "text/html"});
    res.write('<html>'+
      '<head>'+
      '<title>ExampleApp</title>'+
      '<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">'+
      minocloud.toolbar()+
      '<link href="style.css" rel="stylesheet"></link>'+
      '<script type="text/javascript">'+
        'var typeNames = '+JSON.stringify(app_settings.types)+';'+
        'var apiAddress = "/api";'+//Defined here so that index.js is identical to the PHP back-end version
      '</script>'+
      '<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>'+
      '<script src="index.js"></script>'+
      '</head>'+
      '<body></body>'+
    '</html>');
    res.end();

  });
});

/* Process requests for /api using the api module. */
server.post('/api', function(req, res){
  api(req,res);
});

/* Process requests for /activate using the activate 
 * module. */
server.post('/activate', function(req, res){
  activate(req,res);
});

/* Listen on the port specified in the environment 
 * variables or port 80 */
try{
  server.listen(process.env.PORT || 80);
} catch (e){
  console.log(e);
}

/* Print to the console so that we can tell when the 
 * server has started. */
console.log("Server started");