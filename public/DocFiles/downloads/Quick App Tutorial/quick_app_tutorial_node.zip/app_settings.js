/* The app settings as a simple object containing
 * the username and apiKey for this app. */
module.exports = {
  username : "ExampleApp",
  api_key : "cZnXNnscCaVZWKxrwRq302IleqcwwCLm",
  types : {
    /* The ExampleApp.SimplePost.1 type is public. */
    postType : "ExampleApp.SimplePost.1",
  }
};