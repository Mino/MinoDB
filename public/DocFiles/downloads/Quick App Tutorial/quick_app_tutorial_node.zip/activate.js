/* Include the MinoCloud node module that will allow 
 * us to create MinoCloud objects that we can use to 
 * interact with the MinoCloud API. */
var MinoCloud = require('minocloud');

/* Include the app settings. This is an object that 
 * contains the app's username, API key and a list 
 * of types that it will use. */
var app_settings = require("./app_settings");

/* The activation function. */
var activate = function(request, response){

  /* Create a MinoCloud object for this request. */
  var minocloud = new MinoCloud(app_settings.username,app_settings.api_key);

  /* Use the MinoCloud library to process and decrypt 
   * the request to extract the appUser. */
  minocloud.handleActivationRequest(request,response,
    function(appUser,respond){
      /* The respond() function writes to the 
       * response. */

      /* Create a folder named "Posts" in the 
       * appUser's app folder for this app. */
      var postsFolder = {
        'Name' : 'Posts',
        'Path' : '/'+appUser+'/Apps/'+app_settings.username+'/',
        'Folder' : true
      };

      /* Use the saveObjects function to save the 
       * folder. This is a convenience function 
       * that acts a wrapper around the "Save" 
       * API function. */
      minocloud.saveObjects(postsFolder,
        function(error,response){

          /* If there was an error, return it. */
          if(error!=null){
            respond(error);
            return;
          }

          /* If the folder was saved (the response 
           * contains an 'ID') or the folder 
           * already exists (error 43). */
          if(response['ID']!=undefined || response['Invalid']['Name']['Error Number']==43){

            /* Respond with true to let MinoCloud 
             * know that activation was successful. */
            respond(true);
            return;
          }

          /* Something went wrong so respond with the 
           * save response. This error will be visible 
           * during the activation process. */
          respond(response);
          return;
        }
      );
    }
  );
}

module.exports = activate;