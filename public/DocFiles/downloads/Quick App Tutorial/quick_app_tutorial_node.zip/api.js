/* Include the MinoCloud node module that will allow 
 * us to create MinoCloud objects that we can use to 
 * interact with the MinoCloud API. */
var MinoCloud = require('minocloud');

/* Get the Validator class that is defined within the 
 * MinoCloud class. */
var Validator = MinoCloud.Validator;

/* Include the app settings. This is an object that 
 * contains the app's username, API key and a list 
 * of types that it will use. */
var app_settings = require("./app_settings");

/* The API function. */
var api = function(request, response){

  /* Create a MinoCloud object for this API request. */
  var minocloud = new MinoCloud(app_settings.username,app_settings.api_key);

  /* Use the MinoCloud library to process (and decrypt 
   * where appropriate) the request to extract the 
   * parameters. */
  minocloud.handleAPIRequest(request,response,
    function(appUser,caller,functionName,parameters,respond){
      /* The respond() function writes to the 
       * response, using encryption where 
       * appropriate. */

      /* Use a MinoCloud validator to check the 
       * parameters. */
      var validator = new Validator(parameters);

      /* The "Search Posts" function is used to 
       * load the posts upon first loading the 
       * app. */
      if(functionName=="Search Posts"){

        /* Create the search parameters. */
        var searchParams = {
          'Sort By' : 'Created',
          'Sort Order' : 'Descending'
        }

        /* Set an empty object for the postType 
         * key to specify that only items with 
         * this type should be returned. */
        searchParams[app_settings.types.postType] = {};

        /* Use the minocloud object to perform 
         * the search. */
        minocloud.search(
          '/'+appUser+'/Apps/'+app_settings.username+'/Posts/',/* The 'Path' to search. */
          searchParams,/* The parameters. */
          function(error,response){
            if(error!=null){
              /* If there was an error, 
               * return it. */
              respond(error);
              return;
            }

            /* Return the API response. */
            respond(response);
            return;
          }
        );

      /* The "Create Post" function creates an 
       * item from the title and content provided. */
      } else if(functionName=="Create Post"){
        
        /* Use the validator to extract the 
         * "Title" and "Content" values. Both 
         * are required (the true boolean). */
        var title = validator.getValue("Title","string",true);
        var content = validator.getValue("Content","string",true);

        /* If there were any errors related to 
         * extracting the values (missing or 
         * wrong type) then finalErrorCheck 
         * will return an error rather than 
         * null. */
        var finalErrorCheck = validator.finalErrorCheck();
        if(finalErrorCheck!=null){
          /* Return the error. */
          respond(finalErrorCheck);
          return;
        }

        /* Create a blank item with the name 
         * "Post ~ID~". "~ID~" will be replaced 
         * by the ID that the item is assigned 
         * once it is saved. The item will be 
         * saved to the "Posts" folder in the user's 
         * app folder for this app. */
        var toSave = {
          'Name' : 'Post ~ID~',
          'Path' : '/'+appUser+'/Apps/'+app_settings.username+'/Posts/'
        };

        /* Insert the post type with the input values. */
        toSave[app_settings.types.postType] = {
          'Title' : title,
          'Content' : content
        };

        /* Use the saveObjects function to save the 
         * item. This is a convenience function 
         * that acts a wrapper around the "Save" 
         * API function. */
        minocloud.saveObjects(toSave,function(error,response){

          /* If there was an error, return it. */
          if(error!=null){
            response(error);
            return;
          }

          /* Merge the pre-save item with the saving result. 
           * This adds the "ID", "Version", "Created", 
           * "Last Updated" and "Folder" (set to false) keys. */
          var newItem = minocloud.merge(toSave,response);//Merge the items contents with the information acquired by saving such as Created time and Name
           
          /* Send a notification to the appUser. The payload 
           * will be received by the front-end and will be 
           * used to display the new post. */
          minocloud.notify(appUser,{
            'Payload' : {
              'Function' : 'New Post',
              'Post' : newItem
            }
          },function(error,response){
            if(error!=null){
              console.log(error);
              return;
            }
          });
          
          /* Return the response, even though in the 
           * current app it isn't used. */
          respond(response);
          return;
        });
      } else {
        /* A function name that does not exist was requested. */
        console.log("Function does not exist: "+functionName );

        /* Returning false makes the MinoCloud library 
         * output an error detailing that the function 
         * does not exist. */
        return false;
      }

      /* The request used a valid function name so return true to 
       * prevent MinoCloud's library from throwing an error about 
       * using a non-existant function.*/
      return true;
    }
  );
}

module.exports = api;