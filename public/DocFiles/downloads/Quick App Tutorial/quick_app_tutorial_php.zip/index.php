<?php

/* Include app_settings.php (the php file that will create 
 * a MinoCloud API object that we can use). */
include 'app_settings.php';

/* Prints the link to the external javascript file that 
 * will create the toolbar and sets variables that 
 * javascript can use to identify the user if authentication 
 * was successful in 'app_settings.php' */
$MinoCloud->initToolbar();
?>

<!--Include some styles for the post elements-->
<link href="style.css" rel="stylesheet"></link>

<script type="text/javascript">
	/* Make the typeNames available to javascript. */
	var typeNames = <?php echo(json_encode($typeNames)); ?>;

	/* Define the address of the API*/
	var apiAddress = 'api.php';
</script>

<!--Use jQuery-->
<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>

<!--Include the front-end javascript-->
<script src="index.js"></script>