/* Define the post type name here so that it can be used more easily. */
var postType = typeNames.postType;

/* The full name of the Notification Type used by MinoCloud. */
var notificationTypeName = 'Notifications.Notification.1';

/* Use the jQuery ready callback to start the App. */
$(document).ready(function()
{

    /* If authentication was unsuccessful */
    if(MinoCloud_user==null){

        /*Write "Not signed in" on the page.*/
        $("body").append(
            $("<div />").text("Not signed in")
        )
        return;
    }

    /* Keep a record of the Posts indexed by their ID. */
    var posts = {};

    /* The Post class. Used to create an element from an Item containing 
    the Post Type. */
    function Post(object){
        var post = this;

        /* Store the object in the Post. */
        post.object = object;

        /* Create an element to display the title and content. */
        post.element = $("<div />")
        .addClass("post")
        .append(
            $("<div />").addClass("title")
            .text(object[postType]['Title'] + " - " + object['Created'])
        )
        .append(
            $("<div />")
            .text(object[postType]['Content'])
        )

        posts[post.object['ID']] = post;
    }

    /* Create the input area where new Posts can be created consisting of 
    a field for the Title and for the Content. */
    var titleField, contentField;
    $("<div />")
    .append(
        $("<div />").text("Title")
    )
    .append(
        titleField = $("<input type=\"text\" />")
    )
    .appendTo("body");
    $("<div />")
    .append(
        $("<div />").text("Content")
    )
    .append(
        contentField = $("<textarea />").css({
            "width" : "100%",
            "height" : "100px"
        })
    )
    .appendTo("body");

    /* Insert a "Create Post" button beneath the inputs. */
    $("<button />")
    .text("Create Post")
    .appendTo("body")
    .click(function(){
        /* Get the title and content values from the fields. */
        var title = titleField.val();
        var content = contentField.val();

        /* Empty the fields ready for the next post. */
        titleField.val("");
        contentField.val("");

        /*MinoCloud_api is an abstraction atop the jQuery ajax 
        functionality that can be used in conjunction with the 
        'handleAPIRequest' method in MinoCloud's PHP library to 
        simplify your code. */
        MinoCloud_api(
            apiAddress,/* The address of the API. */
            'Create Post',/* The name of the function being called in api.php. */
            {/* The parameters for the 'Create Post' function. */
                "Title" : title,
                "Content" : content
            },
            function(response){
                /* Don't do anything with the response. */
                console.log(response);
            },
            function(error){
                /* For now, just log any errors so that you can see the cause.
                In production you could alert the user or retry the request. */
                console.log(error);
                alert(error);
            }
        );
    });

    /* Create a div for the Posts to be shown. */
    var postsDiv = $("<div />")
    .appendTo("body");

    
    /* Retrieve the existing Posts on page load. */
    MinoCloud_api(
        apiAddress,
        'Search Posts',
        {},/* No parameters for this function. */
        function(response){
            /* response is the output directly from api.php. */

            /* The response should contain an array of objects
             in the 'Objects' key. */
            var objects = response['Objects'];

            /* Empty the postsDiv so that Posts don't get duplicated 
            if this function is called more than once. */
            postsDiv.empty();
            for(i in objects){

                /* Use each search result to create a Post and append it 
                to the bottom of the postsDiv. */
                var object = objects[i];
                var post = new Post(object);
                postsDiv.append(post.element);
            }
        },
        function(error){
            console.trace();
            console.log(error);
            alert(error);
        }
    );

    /* Set the Notification callback function that will receive 
    each Notification from MinoCloud.*/
    MinoCloud_setNotificationCallback(function(notification){
        /* notification contains a MinoCloud object that stores the 
        contents of the Notification and other relevant data. */

        /* The 'Payload' contained in the Notifications.Notification.1
        Type is that which is sent by the notify function in api.php. */
        var payload = notification[notificationTypeName]['Payload'];

        /* Because most Apps have multiple reasons to send Notifications
        the payload includes a 'Function' to specify what the Notication
        is for. */
        if(payload['Function']=='New Post'){

            /* The 'Post' in this case is the Post object sent by api.php. */
            var postObject = payload['Post'];

            /* Create a new Post. */
            var post = new Post(postObject);

            /* Insert the Post at the top of the list. */
            postsDiv.prepend(post.element);
        }
    });
});