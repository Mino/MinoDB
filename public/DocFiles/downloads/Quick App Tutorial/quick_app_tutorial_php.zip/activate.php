<?php
include 'app_settings.php';

/* Initialize the MinoCloud API object. */
$minoCloud = new MinoCloud($app_username,$api_key);

/* Intercepts and decrypts the activation request made by MinoCloud, 
 * checks its authenticity and then runs the named function. */
$minoCloud->activate('activateFunction');

/* This is the activation function specified above that MinoCloud 
 * will invoke when a new user activates your App. The address of 
 * this page should be set in the App Settings for this App under 
 * "Activation URL" and "Page" activation should be selected. */
function activateFunction($app_user){

    //Make these two variable accessible within this function
    global $minoCloud, $app_username;

    /* Create a new Folder named 'Posts' within the App Folder of 
     * the new user. */
    $saveRequest = array(
        'Objects' => array(
            array(
                'Name' => 'Posts',
                'Path' => '/'.$app_user.'/Apps/'.$app_username.'/',
                'Folder' => true
            )
        )
    );
    $saveResponse = $minoCloud->api('Save',$saveRequest);

    /*Catches the potential error number caused by 
    the folder already existing. The @ symbol prevents 
    PHP from throwing an error if the index does not 
    exist; leaving the value as null if it is not 
    present.*/
    @$folderError = $saveResponse['Invalid']['Name']['Error Number'];
    //If the folder was successfully saved or already exists
    if(isset($saveResponse['ID']) || $folderError==43){
        return true;//Unless you return true, the App won't be activated and this can be called repeatedly
    }
    return $saveResponse;
}
?>