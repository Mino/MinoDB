<?php
	/* Include the MinoCloud library. */
	include 'minocloud.php';

	/* Set the username for the App and the API Key. */
	$app_username = '__YOUR_APP_USERNAME__';
	$api_key = '__YOUR_API_KEY__';

	/* Initialize your MinoCloud API interface. */
	$MinoCloud = new MinoCloud($app_username,$api_key);

	/* Attempt authentication. The result will be checked later. */
	$MinoCloud->authenticate();

	/* Make a list of the types used so that they can be 
	 * used throughout the app. The only type used in this 
	 * example is the SimplePost type, made public by the 
	 * ExampleApp user. */
	$typeNames = array(
		'postType' => 'ExampleApp.SimplePost.1'
	);
?>