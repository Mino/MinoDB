<?php

/*Include app_settings.php (the php file that includes 
the $app_username and $api_key). */
include 'app_settings.php';

/* Initialize the MinoCloud API object. */
$minoCloud = new MinoCloud($app_username,$api_key);

/* Invoke MinoCloud's authentcation procedure. */
$minoCloud->authenticate();

/* Use MinoCloud to handle the raw request and use the function 
'handleAPI' (defined below) to react to the request's contents. */
$minoCloud->handleAPIRequest('handleAPI');

//The function called by the line above
function handleAPI($app_user,$caller,$function,$parameters){
	/* $caller is the name of the App making the request to this API 
	(none if AJAX)*/

	/* $app_user is the username of the user that the request is on 
	behalf of. (an App will refer to a user when making a request). 
	If the request is made via AJAX the $app_user is just the name of 
	the user. */

	/* Make the $app_username and $minoCloud variables accessible 
	within this function. */
	global $app_username, $minoCloud;

	/* Make the $typeNames defined in app_settings.php accessible 
	within this function. */
	global $typeNames;

	//If there is no $caller then this is an AJAX request
	$isAJAX = $caller==null;

	/* Use the Validator class provided by MinoCloud to validate 
	the parameters. This is used in the 'Create Post' function below. */
	$paramVal = new Validator($parameters);	

	/* This is the function that the App will call when it first loads to 
	populate the current posts. */	
	if($function=='Search Posts'){

		/* Perform a simple search of the 'Posts' folder to find all of 
		the user's Posts. Including the post type with no parameters 
		indicates that we want only Items that include that Type to 
		be returned. */
		$search = $minoCloud->api('Search',array(
			'Path' => '/'.$app_user.'/Apps/'.$app_username.'/Posts/',
			'Sort By' => 'Created',
			'Sort Order' => 'Descending',
			$typeNames['postType'] => array()
		));

		/* Return the direct response from the search. The front-end will 
		handle the output. */
		return $search;
		
	/* This is the function that the App will call to create a new Post. */
	} else if($function=='Create Post'){

		/* Use the MinoCloud Validator to retrieve the values "Title" and 
		"Content" from the request and check they are of the correct format. */ 
		$title = $paramVal->getValue("Title","string",true,true);
		$content = $paramVal->getValue("Content","string",true,true);

		/* The finalErrorCheck function compiles an error if there were any 
		problems with the request or null if there were no issues. */
		$paramError = $paramVal->finalErrorCheck();

		//Return the error if it was created.
		if($paramError!=null){
			return($paramError);
		}
		
		/* Create an Item with the Post Type that contains the Title and 
		Content. */
		$postObject = array(
			'Name' => 'Post ~ID~',
			'Path' => '/'.$app_user.'/Apps/'.$app_username.'/Posts/',
			'Folder' => false,
			$typeNames['postType'] => array(
				'Title' => $title,
				'Content' => $content
			)
		);

		/* Save the Item. */
		$saveResponse = $minoCloud->save($postObject);

		/* If there is a key ['Objects'][0]['ID'] in the response then the 
		Item was saved successfully. */
		if(isset($saveResponse['ID'])){

			/* Use minocloud_merge to use combine the fields from the request 
			and response to build the full Object. */
			$wholeItem = minocloud_merge($postObject,$saveResponse);

			/* Send a notification to $app_user to push the new Post to all 
			of their open windows. */
			$minoCloud->notify($app_user,array(
				'Payload' => array(
					'Function' => 'New Post',
					'Post' => $wholeItem
				)
			));
		}

		/* Send the save response to the front-end for debugging purposes. */
		return $saveResponse;
	}
}
?>