<?php

//Check for MCrypt and CURL. Both are required by MinoCloud.
if(!function_exists('mcrypt_create_iv')){
	die('The MinoCloud API requires the Mcrypt library, which is not present.');
}
if(!function_exists('curl_init')){
	die('The MinoCloud API requires the CURL library, which is not present.');
}

/* Start of generic functions required by MinoCloud */
if(!function_exists('json_encode')){
	if(isset($fc_json_lib_path)){
		include_once($fc_json_lib_path);
	} else {
		include_once("MinoCloud/JSON.php");
	}
	$GLOBALS['JSON_OBJECT'] = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
	function json_encode($value)
	{
		return $GLOBALS['JSON_OBJECT']->encode($value); 
	}
	function json_decode($value)
	{
		return $GLOBALS['JSON_OBJECT']->decode($value); 
	}
}
if(!function_exists('hex2bin')){
	function hex2bin($hex_string){
		if(!ctype_xdigit($hex_string)){	
			return "";
		}
	
		return pack("H*" , $hex_string);
	}
}
if(!function_exists('is_assoc')){
	function is_assoc($array) {
		return (bool)count(array_filter(array_keys($array), 'is_string'));
	}
}

/* End of generic functions */

if(!function_exists('isSubpathOf')){
	function isSubpathOf($subpath,$parentpath){
		if(strlen($subpath)>strlen($parentpath)){
			return false;
		}
		return (substr($parentpath, 0, strlen($subpath))==$subpath);
	}
}

if(!function_exists('isFolderPath')){
	function isFolderPath($path){
		return $path[strlen($path)-1]=="/";
	}
}

if(!function_exists('minocloud_merge')){
	function minocloud_merge($save,$result){
		$wholeObject = array_merge($save,$result);
		if(isset($wholeObject['Counters'])){
			unset($wholeObject['Counters']);
		}
		return $wholeObject;
	}
}

if(!function_exists('splitToObjectNames')){
	function splitToObjectNames($path){
		$isFolder = isFolderPath($path);
		if($isFolder){
			$split = explode("/", substr($path,1,strlen($path)-2));
		} else {
			$split = explode("/", substr($path,1,strlen($path)-1));
		}
		return $split;
	}
}

if(!function_exists('utf8_strlen')){
	function utf8_strlen($s) {
		$c = strlen($s); $l = 0;
		for ($i = 0; $i < $c; ++$i) if ((ord($s[$i]) & 0xC0) != 0x80) ++$l;
		return $l;
	}
}

if(!function_exists('hash_hmac')){
	function hash_hmac($algo, $data, $key, $raw_output = false)
	{
	    $blocksize = 64;
	    $ipad = str_repeat("\x36", $blocksize);
	    $opad = str_repeat("\x5c", $blocksize);
	    if (strlen($key) > $blocksize) {
	        $key = pack('H*', sha1($key));
	    } else {
	        $key = str_pad($key, $blocksize, "\x00");
	    }
	    $ipad ^= $key;
	    $opad ^= $key;
	    return pack('H*',sha1($opad.pack('H*',sha1($ipad.$data))));
	}
}

if(!function_exists('removeVariableFromURL')){
	function removeVariableFromURL($url, $varname) {
	    list($urlpart, $qspart) = array_pad(explode('?', $url), 2, '');
	    parse_str($qspart, $qsvars);
	    
	    unset($qsvars[$varname]);
	    $newqs = http_build_query($qsvars);
	    return $urlpart . '?' . $newqs;
	}
}

if(!class_exists('MinoCloud')){ 

	class MinoCloud {
	
		var $username;
		var $password;
		var $appUser = null;
		var $dieOnCommunicationError = false;
		var $failureCallback = "";
		
		function __construct($setUsername=0,$setPassword=0,$performAuthentication=0,$initToolbar=0) {
			$this->username = $setUsername;
			$this->password = sha1($setPassword);
			if($performAuthentication==true){
				$this->authenticate();
				if($initToolbar==true){
					$this->initToolbar();
				}
			} else if($initToolbar==true){
				die('MinoCloud Error: Authentication must be performed before the toolbar can be initialised.');
			}
		}
		
		function MinoCloud($setUsername=0,$setPassword=0,$performAuthentication=0,$initToolbar=0){
			$this->__construct($setUsername,$setPassword,$performAuthentication,$initToolbar);
		}
	
		function hasAppUser() {
			return ($this->appUser!=NULL);
		}
		
		function setDieOnCommunicationError($toSet){
			$this->dieOnCommunicationError = $toSet;
		}
		
		function setCommunicationFailureCallback($toSet){
			$this->failureCallback = $toSet;
		}
		
		function removePaddingFromTokenString($tokenString){
			$numOfPads = substr($tokenString,0,3);
			$tokenID = substr($tokenString,$numOfPads+3);
			return $tokenID;
		} 
		
		function setUserCookie($encryptedTokenID) {
			$expire=time()+60*60*24*30;
			setcookie('MinoToken', $encryptedTokenID, $expire);
		}

		function activate($callback){
			$_POST['activationCallback'] = $callback;
			function handleActivationRequestCallback($appUser,$caller,$function,$parameters){
				$callbackName = $_POST['activationCallback'];
				$validator = new Validator(null);
				if($caller==null || $caller!='Mino'){
					$validator->addToInvalid('Caller',array(
						'Error' => 'Activation must be called by "Mino"',
						'Error Number' => 999
					));
					return $validator->finalErrorCheck();
				}
				if($function!='Activate'){
					$validator->addToInvalid('Function',array(
						'Error' => 'Only the "Activate" function will be accepted',
						'Error Number' => 998
					));
					return $validator->finalErrorCheck();
				}
				
				$activationResponse = call_user_func_array($callbackName,array($appUser));
				
				ob_start();
				?>
				<html>
				<script type="text/javascript">
					
					//The output of your activation process
					var output = <?php echo(json_encode($activationResponse)); ?>;

					parent['postMessage'](
			            JSON.stringify(output),
			            "http://minocloud.com/"
			        );
				</script>
				</html>
				<?php

				$output = ob_get_clean();

				return $output;
			}
			$this->handleAPIRequest('handleActivationRequestCallback',true);
		}

		function postRequest($data,$url="api.minocloud.com:80") {
			if($url==null){
				$url = "api.minocloud.com:80";
			}

	    	$session = curl_init($url);
			curl_setopt ($session, CURLOPT_POST, true);
			curl_setopt ($session, CURLOPT_POSTFIELDS, $data);
			
			curl_setopt($session, CURLOPT_HEADER, false);
			curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
			 
			$response = curl_exec($session);
			curl_close($session);
			return $response;
		}
		
		function handleAPIRequest($callback,$postUnencrypted=null){
			$caller = null;
			$request = null;
			$encrypt = true;
			if($postUnencrypted!=null){
				$encrypt = !$postUnencrypted;
			}
			if(isset($_POST['request'])){
				function writeOut($response,$apiObj,$encrypt){
					if(gettype($response)=='array'){
						$response = json_encode($response);
					}
					if($encrypt==false){
						die($response);
					}
					die($apiObj->encrypt($response));
				}
				$request = json_decode($this->decrypt($_POST['request']),true);
				if($request==null){
					die("Could not decrypt request");
				}
				if(!isset($request['App User'])){
					if($postUnencrypted!=null && $postUnencrypted==true){
						die('Missing App User');
					} else {
						die($this->encrypt('Missing App User'));
					}
				}	
				$appUser = $request['App User'];
				$caller = $request['Caller'];
				unset($request['App User']);
				unset($request['Caller']);
				unset($request['Time']);
			} else if(($postUnencrypted==null || $postUnencrypted==false) && isset($_POST['ajax'])){
				function writeOut($response,$apiObj,$encrypt){//$encrypt is ignored
					if(gettype($response)=='array'){
						$response = json_encode($response);
					}
					die($response);
				}

				if(!isset($_POST['MinoCloud_ajaxToken']) 
					||
					$this->decrypt($_POST['MinoCloud_ajaxToken'])!=$this->ajaxTokenValue
					){
					die("Cross-site request forgery prevention mechanism.");
				}
				if($this->hasAppUser()){
					$appUser = $this->appUser;
				} else {
					writeOut('NOTSIGNEDIN',$this,$encrypt);
					die();
				}
				$request = json_decode(stripcslashes($_POST['ajax']),true);
			} else {
				if($postUnencrypted!=null && $postUnencrypted==true){
					die('No request was made. "request" must be present in the POST values of the request.');
				} else {
					die('No request was made. Either "ajax" or "request" must be present in the POST values of the request.');
				}	
			}
			
			$validator = new Validator($request);
			$function = $validator->getValue('Function','string',true,true);
			$parameters = $validator->getValue('Parameters','array',true,true);
			$time = $validator->getValue('Time','double',false,true);//Not required/used
			$finalCheck = $validator->finalErrorCheck();
			if($finalCheck!=null){
				writeOut($finalCheck,$this,$encrypt);	
			}
			
			if(function_exists($callback)){
				$output = call_user_func_array($callback,array($appUser,$caller,$function,$parameters));
				if($output==null && !is_array($output)){								
					$validator->addToInvalid('Function',array(
						'Error' => 'Function does not exist',
						'Error Number' => 1000
					));
					writeOut($validator->finalErrorCheck(),$this,$encrypt);
				} else {
					writeOut($output,$this,$encrypt);
				}
			} else {
				die('The function '.$callback.' is not defined.');
			}
		}
		
		function initToolbar(){
			?>
<script type="text/javascript">
var MinoCloud_app = <?php echo(json_encode($this->username)); ?>;
var MinoCloud_user = <?php echo(json_encode($this->appUser)); ?>;
<?php
if($this->hasAppUser()){ ?>
var MinoCloud_ajaxToken = <?php echo(json_encode($this->ajaxToken)); ?>;
<?php } ?>
</script>
<script type="text/javascript" src="http://minocloud.com/interface.js"></script>
<?php
		}
		
		function authenticate() {
		
			if(isset($_GET['minocloud_session_cookie'])){

				$sentToken = $_GET['minocloud_session_cookie'];

				if($sentToken=='invalid'){
					setcookie('MinoToken','',1);
				} else {
				
					$getForSession = hex2bin($sentToken);	
					setcookie('MinoToken',$getForSession,time()+24*60*60);
					$_COOKIE['MinoToken'] = $getForSession;
				}
				
				$newURL = removeVariableFromURL($_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'], 'minocloud_session_cookie');

				if( isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on' ) {
					$newURL = "https://".$newURL;
				} else {
					$newURL = "http://".$newURL;
				}
    
			    header('Location: '.$newURL);
				
			}
		
			if(isset($_COOKIE['MinoToken'])){	
				$encryptedToken = $_COOKIE['MinoToken'];
				$decryptedTokenID = $this->Decrypt($encryptedToken, $this->password);
				
				
				if($decryptedTokenID=='ERROR'){
					setcookie('MinoToken','',1);
				} else {
				
					$tokenID = $this->removePaddingFromTokenString($decryptedTokenID);
					
					$toSend = array(
						"Function" => "Check Token",
						"Parameters" => array(
							"Token ID" => $tokenID
					 	)
					);
				
					$array = $this->makeRequest($toSend);
					
					if(isset($array['Username'])){
						$this->appUser = $array['Username'];
						$this->ajaxTokenValue = $this->appUser.'.'.$this->username;
						$this->ajaxToken = $this->encrypt($this->ajaxTokenValue);
						return $array['Username'];
					} else if(isset($array['Error'])){
						if($array['Error Number']==5){
							die("No response from MinoCloud");
						} else if(isset($array['Invalid']['Token ID'])){
							$this->appUser = null;
							setcookie('MinoToken','',1);
						} else if($array['Error Number']==2){							
							if(strlen($this->failureCallback)!=0){
								call_user_func($this->failureCallback);
							}
							if($this->dieOnCommunicationError==true){
								die();
							}
						} else {
							die("Error interacting with MinoCloud servers.");
						}
					} else {
						return null;
					}
					
					
				}
			}
			return null;
		}
		
		function makeSessionRequest($phpRequest,$url=null){
			
			if(!isset($_COOKIE['MinoUsername']) || !isset($_COOKIE['MinoSessionID']) || !isset($_COOKIE['MinoSessionKey'])){
				return array("Error"=>"Not signed in.","Error Number"=>5);
			}
			
			if(is_object($phpRequest)){
				$phpRequest->Time = microtime(true);
			} else if(is_array($phpRequest)){
				$phpRequest['Time'] = microtime(true);
			} else {
				return array("Error"=>"Request is not an object or an array.","Error Number"=>5);
			}
			
			
			$requestJSON = json_encode($phpRequest);
			$encryptedRequest = $this->encrypt($requestJSON,$_COOKIE['MinoSessionKey']);
			$sendsafestring=urlencode($encryptedRequest);
	
			$fieldstr='username='.urlencode(stripslashes($_COOKIE['MinoUsername'])).'&sessionid='.$_COOKIE['MinoSessionID'].'&request='.$sendsafestring;
			
			$callStart = explode(' ', microtime());
			$callStart = $callStart[1] + $callStart[0];
			@$rawResponse = $this->postRequest($fieldstr,$url);
			$array = json_decode($rawResponse,true);
			if(!empty($array)){
				return $array;
			}
			$callFinish = explode(' ', microtime());
			$callFinish = $callFinish[1] + $callFinish[0];
			$total_time = round(($callFinish - $callStart), 4);
			if(empty($rawResponse)){
				if(strlen($this->failureCallback)!=0){
					call_user_func($this->failureCallback);
				}
				if($this->dieOnCommunicationError==true){
					die();
				}	
				return array("Error"=>"No response from MinoCloud","Error Number"=>5);
			} else {
				$response = $this->decrypt(substr($rawResponse,0,strlen($rawResponse)-1),$_COOKIE['MinoSessionKey']);
				
				$array = json_decode($response,true);
				if(empty($array)){
					if(strlen($this->failureCallback)!=0){
						call_user_func($this->failureCallback);
					}
					if($this->dieOnCommunicationError==true){
						die();
					}
					return array("Error"=>"Corrupt response","Error Number"=>5, "Response" => $response);
				} else {
					$array['Response Time'] = $total_time;
					return $array;
				}
			}
		}
		
		function makeRequest($phpRequest,$url=null){
		
			if(is_object($phpRequest)){
				$phpRequest->Time = microtime(true);
			} else if(is_array($phpRequest)){
				$phpRequest['Time'] = microtime(true);
			} else {
				return array("Error"=>"Request is not an object or an array.","Error Number"=>5);
			}
		
			$requestJSON = json_encode($phpRequest);
			$encryptedRequest=$this->encrypt($requestJSON);
			$sendsafestring=urlencode($encryptedRequest);
			$fieldstr='username='.urlencode($this->username).'&request='.$sendsafestring;
			$callStart = explode(' ', microtime());
			$callStart = $callStart[1] + $callStart[0];
			@$rawResponse = $this->postRequest($fieldstr,$url);
			$array = json_decode($rawResponse,true);
			if(!empty($array)){
				return $array;
			}
			$callFinish = explode(' ', microtime());
			$callFinish = $callFinish[1] + $callFinish[0];
			$total_time = round(($callFinish - $callStart), 4);
	
			if(empty($rawResponse)){
				if(strlen($this->failureCallback)!=0){
					call_user_func($this->failureCallback);
				}
				if($this->dieOnCommunicationError==true){
					die();
				}	
				return array("Error"=>"No response from MinoCloud","Error Number"=>5);
			} else {
				$response = $this->decrypt(substr($rawResponse,0,strlen($rawResponse)-1));
				$array = json_decode($response,true);
				if(empty($array)){
					if(strlen($this->failureCallback)!=0){
						call_user_func($this->failureCallback);
					}
					if($this->dieOnCommunicationError==true){
						die();
					}
					return array("Error"=>"Corrupt response","Error Number"=>5, "Response"=>$response);
				} else {
					$array['Response Time'] = $total_time;
					return $array;
				}
			}
			
		}
		
		function api($functionName,$parameters){
			return $this->makeRequest(array(
				'Function' => $functionName,
				'Parameters' => $parameters
			));
		}
		
		function notify($usernameVal, $parameters){
			if(gettype($usernameVal)!='string' && isset($usernameVal[0]) ){
				$parameters['Recipients'] = $usernameVal;
			} else {
				$parameters['Recipients'] = array($usernameVal);
			}
			return $this->makeRequest(array(
				'Function' => 'Notify',
				'Parameters' => $parameters
			));
		}
		
		function save($object){
			if(!is_assoc($object)) {
				$response = $this->api("Save",array(
					'Objects' => $object
				));
				if(isset($response['Invalid'])){
					return $response['Invalid']['Objects'];
				} else if(isset($response['Objects'])){
					return $response['Objects'];
				}
				return $response;
			} else {
				$response = $this->api("Save",array(
					'Objects' => array(
						$object
					)
				));
				if(isset($response['Invalid'])){
					return $response['Invalid']['Objects'][0];
				} else if(isset($response['Objects'])){
					return $response['Objects'][0];
				}
				return $response;
			}
		}

		function get($addresses){
			if(gettype($addresses)!='string' && isset($addresses[0]) ) {
				$response = $this->api("Get",array(
					'Addresses' => $addresses
				));
				if(isset($response['Invalid'])){
					return $response['Invalid']['Objects'];
				} else if(isset($response['Objects'])){
					return $response['Objects'];
				}
				return $response;
			} else {
				$response = $this->api("Get",array(
					'Addresses' => array(
						$addresses
					)
				));
				if(isset($response['Invalid'])){
					return $response['Invalid']['Objects'][0];
				} else if(isset($response['Objects'])){
					return $response['Objects'][0];
				}
				return $response;
			}
		}
		
		function delete($address){
			if(gettype($address)!='string' && isset($address[0])){
				return $this->api("Delete",array(
					"Delete" => $address
				));
			} else {
				return $this->api("Delete",array(
					'Delete' => array(
						$address
					)
				));
			}
		}
		
		function encrypt($str, $pass=0){
			if($pass==null){
				return $this->doEncrypt($str,$this->password);
			}
			return $this->doEncrypt($str,$pass);
		}
		
		function decrypt($str, $pass=0){
			if($pass==null){
				return $this->doDecrypt($str,$this->password);
			}
			return $this->doDecrypt($str,$pass);
		}
		
		function pkcs5_pad ($text, $blocksize = 16) {
			$pad = $blocksize - (utf8_strlen($text) % $blocksize);
			return $text . str_repeat(chr($pad), $pad);
		}
	
		function pkcs5_unpad($text)
		{
			$pad = ord($text{strlen($text)-1});
			if ($pad > strlen($text)) return 'ERROR';
			if (strspn($text, chr($pad), strlen($text) - $pad) != $pad) return false;
			return substr($text, 0, -1 * $pad);
		}
	
		function hex2bin($hex_string){
			return pack("H*" , $hex_string);
		}
	
		function generateIV() {
			return base64_encode(mcrypt_create_iv(16, MCRYPT_DEV_URANDOM));
		}
	
		function str_hash_pbkdf2($p, $s, $c, $kb, $a)
		{
			$dk = '';
			for ($block=1; $block<=$kb; $block++){
				$ib = $h = hash_hmac($a, $s . pack('N', $block), $p, true);
				for ($i=1; $i<$c; $i++){
					$ib ^= ($h = hash_hmac($a, $h, $p, true));
				}	
				$dk .= $ib;
			}
			return substr($dk, 0, $kb);
		}
		
		function keyDerive($key,$iv){
			return $this->str_hash_pbkdf2($key, $iv, 32, 16, 'sha1');
		}
	
		function doEncrypt($text, $key) {
			$iv = $this->generateIV();
			$encrypted = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $this->keyDerive($key,$iv), $this->pkcs5_pad($text), MCRYPT_MODE_CBC, base64_decode($iv)));
			return $iv.$encrypted;
		}
	
		function doDecrypt($text, $key) {
	
			$iv = substr($text,0,24);
			$encrypted = substr($text,24);
	
			$decrypted = "DECRYPTION ERROR";
			@$decrypted = $this->pkcs5_unpad(mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $this->keyDerive($key,$iv), base64_decode($encrypted), MCRYPT_MODE_CBC,  base64_decode($iv)));
	
			return $decrypted;
		}
	
	
	}
}

if(!class_exists('Validator')){ 
	class Validator {
	
		var $validating;
		var $missing;
		var $invalid;
		var $unrecognized;
		var $recognized;
		
		function __construct($validating) {
			$this->validating = $validating;
			$this->missing = array();
			$this->invalid = array();
			$this->unrecognized = array();
			$this->recognized = array();
		}

		function Validator($validating){
			$this->__construct($validating);
		}
		
		/*
		Valid types: string, object, array, integer, double, float
		*/
		function getValue($fieldName,$type,$required){
		
			$value = null;

			array_push($this->recognized,$fieldName);
			
			@$value = $this->validating[$fieldName];
			
			$keyType = gettype($value);
			
			if($keyType!="NULL" && !($keyType=="integer" && ($type=="float" || $type=="double")) && $keyType!=$type){				
				$this->invalid[$fieldName] = array(
					"Error" => "Incorrect field type.",
					"Error Number" => 2
				);
				return null;
			} 
			
			if(!is_bool($value) && $value==null && $value!==0 && $keyType!="array"){
				if($required==true){
					$this->addToMissing($fieldName);
				}
				return null;
			}
			
			return $value;
		}
		
		function addToInvalid($fieldName,$toAdd){
			$this->invalid[$fieldName] = $toAdd;
		}
		
		function addToMissing($fieldName){
			$this->missing[$fieldName] = array(
				"Error" => "Field missing.",
				"Error Number" => 1
			);
		}
		
		function addToUnrecognized($fieldName){
			$this->unrecognized[$fieldName] = array(
				"Error" => "Unrecognized field.",
				"Error Number" => 4
			);
		}
		
		function finalErrorCheck(){
			$returning = array();

			if($this->validating!=null){
				foreach($this->validating as $key=>$value){
					if(!in_array($key, $this->recognized)){
						$this->addToUnrecognized($key);
					}
				}
			}
			
			if(!empty($this->missing)){
				$returning['Missing'] = $this->missing;
			}
			if(!empty($this->invalid)){
				$returning['Invalid'] = $this->invalid;
			}
			if(!empty($this->unrecognized)){
				$returning['Unrecognized'] = $this->unrecognized;
			}
			
			if(!empty($returning)){
				$returning["Error"] = "One or more errors.";
				$returning["Error Number"] = 0;
				return $returning;
			}
			
			return null;
		}
	}
}


?>
